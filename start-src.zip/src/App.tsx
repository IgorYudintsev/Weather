import React, {useState} from 'react';
import './App.css';

function App() {


    return (
        <div className="App">
            <h1>Weather App</h1>
        </div>
    );
}

export default App;